create table Courses(
course_id serial primary key,
course_code varchar(30),
name varchar(30),
subject varchar(30),
instructor varchar(30),
weeks int,
description text);

