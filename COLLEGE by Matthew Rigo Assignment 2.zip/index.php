<!DOCTYPE html>

<html>
    
<document class="a">     


<head>
  
    <title>Index</title>
   <link rel="stylesheet" type="text/css" href="course.css">
    <meta charset=utf-8>
       <?php
    include("header.inc")     
 ?>
    
   
    
     <nav class="a">
        <?php
    include("nav.inc")   
    ?>
    </nav>
    
    <h1>About the University</h1>
    
</head>
           
    
<body>
 <p> The Rigo University is a fine institution that specialises in information technology, business, the arts and architecture.
    </p>

</body>
       <?php
    include("footer.inc")   
    ?>    
</document>       
</html>